import type { IconProps } from "./types"

export function IconTrendingUp({ size = 18, className }: IconProps) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 18 18" fill="none" className={className}>
      <path d="M1.75 12.25L5.396 8.60401C5.591 8.40901 5.908 8.40901 6.103 8.60401L9.396 11.897C9.591 12.092 9.908 12.092 10.103 11.897L16.249 5.75101" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M11.25 5.75H16.25V10.75" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}
