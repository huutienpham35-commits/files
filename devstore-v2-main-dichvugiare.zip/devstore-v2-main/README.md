# DevStore V2

Dashboard quản lý dịch vụ mã nguồn, website, logo, cronjob, tên miền.

## Tech Stack

- **Framework**: Next.js 16 (App Router, Turbopack)
- **Styling**: Tailwind CSS v4 + shadcn/ui
- **Backend**: tRPC v11 + MongoDB (Mongoose)
- **Auth**: JWT httpOnly cookies + middleware protection
- **UI**: Sonner (toast), nextjs-toploader (progress bar)

## Yêu cầu

- Node.js >= 18
- MongoDB (local hoặc Atlas)

## Setup Production

### 1. Clone repo

```bash
git clone https://github.com/minhnelson/devstore-v2.git
cd devstore-v2
```

### 2. Install dependencies

```bash
npm install
```

### 3. Tạo file `.env`

```env
NODE_ENV=production
NEXT_PUBLIC_APP_URL=https://yourdomain.com
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/devstore?retryWrites=true&w=majority
JWT_SECRET=your-super-secret-key-min-32-chars
```

### 4. Build

```bash
npm run build
```

### 5. Start production server

```bash
npm start
```

Mặc định chạy port 3000. Dùng reverse proxy (Nginx/Caddy) trỏ domain vào.

### 6. Chạy với PM2 (recommended)

```bash
npm install -g pm2
pm2 start npm --name "devstore" -- start
pm2 save
pm2 startup
```

## Setup Development

```bash
npm install
npm run dev
```

Truy cập `http://localhost:3000`

## Cấu trúc thư mục

```
src/
├── app/                  # Next.js App Router pages
│   ├── api/trpc/         # tRPC HTTP handler
│   ├── authentication/   # Login, Register
│   └── dashboard/        # Protected dashboard
├── components/           # UI components
│   ├── icons/            # Pure SVG icon components
│   ├── dashboard/        # Dashboard-specific components
│   └── ui/               # shadcn/ui primitives
├── controllers/          # Business logic (MVC)
├── models/               # Mongoose models
├── trpc/                 # tRPC setup + routers
│   ├── init.ts           # Context, procedures
│   ├── client.tsx        # Client provider
│   └── routers/          # Feature routers
├── lib/                  # DB connection, utilities
└── middleware.ts         # Route protection
```

## Environment Variables

| Variable | Mô tả |
|----------|--------|
| `NODE_ENV` | `development` hoặc `production` |
| `NEXT_PUBLIC_APP_URL` | URL public của app |
| `MONGODB_URI` | MongoDB connection string |
| `JWT_SECRET` | Secret key cho JWT (min 32 chars) |
