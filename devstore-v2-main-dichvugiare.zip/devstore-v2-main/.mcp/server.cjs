/* eslint-disable */
"use strict";

// CRITICAL: stdout phải chỉ chứa JSON-RPC. Mọi log → stderr.
// Override console.log để tránh dependency log vào stdout phá protocol.
const _origLog = console.log;
console.log = function (...args) {
  process.stderr.write(args.map((a) => (typeof a === "string" ? a : JSON.stringify(a))).join(" ") + "\n");
};

const { Server } = require("@modelcontextprotocol/sdk/server/index.js");
const { StdioServerTransport } = require("@modelcontextprotocol/sdk/server/stdio.js");
const { CallToolRequestSchema, ListToolsRequestSchema } = require("@modelcontextprotocol/sdk/types.js");
const path = require("path");
const fs = require("fs");

// Read .env manually to avoid dotenv stdout pollution
function loadEnv() {
  const envPath = path.join(__dirname, "..", ".env");
  if (!fs.existsSync(envPath)) return;
  const content = fs.readFileSync(envPath, "utf-8");
  for (const line of content.split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/i);
    if (!m) continue;
    let val = m[2];
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (!process.env[m[1]]) process.env[m[1]] = val;
  }
}
loadEnv();

const server = new Server(
  { name: "vankhanh-mongodb-mcp", version: "1.0.0" },
  { capabilities: { tools: {} } }
);

// Lazy mongoose — load chỉ khi cần (tránh deprecation warnings lúc start)
let mongoose = null;
let dbConnected = false;
async function connectDb() {
  if (!mongoose) mongoose = require("mongoose");
  if (dbConnected) return;
  const uri = process.env.MONGODB_URI;
  if (!uri) throw new Error("MONGODB_URI is not set in .env");
  await mongoose.connect(uri, {
    maxPoolSize: 5,
    minPoolSize: 1,
    serverSelectionTimeoutMS: 5000,
  });
  dbConnected = true;
}

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: "list_collections",
      description: "List all collections in the vankhanh MongoDB database.",
      inputSchema: { type: "object", properties: {} },
    },
    {
      name: "find_documents",
      description: "Find documents in a specific MongoDB collection.",
      inputSchema: {
        type: "object",
        properties: {
          collection: { type: "string" },
          query: { type: "object" },
          limit: { type: "number" },
          projection: { type: "object" },
          sort: { type: "object" },
        },
        required: ["collection"],
      },
    },
    {
      name: "aggregate_documents",
      description: "Run aggregation pipeline.",
      inputSchema: {
        type: "object",
        properties: {
          collection: { type: "string" },
          pipeline: { type: "array", items: { type: "object" } },
        },
        required: ["collection", "pipeline"],
      },
    },
    {
      name: "count_documents",
      description: "Count documents matching a filter.",
      inputSchema: {
        type: "object",
        properties: { collection: { type: "string" }, query: { type: "object" } },
        required: ["collection"],
      },
    },
    {
      name: "list_indexes",
      description: "List indexes on a collection.",
      inputSchema: {
        type: "object",
        properties: { collection: { type: "string" } },
        required: ["collection"],
      },
    },
    {
      name: "explain_query",
      description: "Run explain('executionStats') on a find query.",
      inputSchema: {
        type: "object",
        properties: {
          collection: { type: "string" },
          query: { type: "object" },
          sort: { type: "object" },
          limit: { type: "number" },
        },
        required: ["collection"],
      },
    },
  ],
}));

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  await connectDb();
  const { name, arguments: args } = request.params;
  const db = mongoose.connection.db;

  try {
    if (name === "list_collections") {
      const cols = await db.listCollections().toArray();
      return { content: [{ type: "text", text: JSON.stringify(cols.map((c) => c.name), null, 2) }] };
    }
    if (name === "find_documents") {
      const col = db.collection(args.collection);
      let cursor = col.find(args.query || {}, { projection: args.projection });
      if (args.sort) cursor = cursor.sort(args.sort);
      const docs = await cursor.limit(args.limit || 50).toArray();
      return { content: [{ type: "text", text: JSON.stringify(docs, null, 2) }] };
    }
    if (name === "aggregate_documents") {
      const docs = await db.collection(args.collection).aggregate(args.pipeline).toArray();
      return { content: [{ type: "text", text: JSON.stringify(docs, null, 2) }] };
    }
    if (name === "count_documents") {
      const count = await db.collection(args.collection).countDocuments(args.query || {});
      return { content: [{ type: "text", text: JSON.stringify({ count }, null, 2) }] };
    }
    if (name === "list_indexes") {
      const indexes = await db.collection(args.collection).indexes();
      return { content: [{ type: "text", text: JSON.stringify(indexes, null, 2) }] };
    }
    if (name === "explain_query") {
      let cursor = db.collection(args.collection).find(args.query || {});
      if (args.sort) cursor = cursor.sort(args.sort);
      if (args.limit) cursor = cursor.limit(args.limit);
      const stats = await cursor.explain("executionStats");
      return { content: [{ type: "text", text: JSON.stringify(stats, null, 2) }] };
    }
    throw new Error("Tool not found: " + name);
  } catch (err) {
    return { isError: true, content: [{ type: "text", text: err.message }] };
  }
});

(async () => {
  const transport = new StdioServerTransport();
  await server.connect(transport);
})().catch((err) => {
  process.stderr.write("FATAL: " + (err && err.stack ? err.stack : String(err)) + "\n");
  process.exit(1);
});
